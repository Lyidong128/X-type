three-model visual outputs
v_list=0.500,0.800,1.000
params: t=0.3, w=1.0, lm=0.1
Each model directory contains:
  01_bulk_band/
  02_ribbon/
  03_obc_marked/ (red points = states used in WF summation)
  04_wf_sum/
  summary_*.csv and obc_marked_states_*.csv
